'use strict';

var profileTicker = angular.module('profileTicker', ['profileticker']);

sportsTickerDemo.controller("TickerFeedCtrl", function($scope, $http){

    $http.get('profile.json').then(function(response){
        $scope.feed = response.data;
    });

});

